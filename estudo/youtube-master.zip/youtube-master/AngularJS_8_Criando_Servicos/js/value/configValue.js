angular.module("listaTelefonica").constant("config", {
	baseUrl: "http://localhost:3412"
});