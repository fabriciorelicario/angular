var regExp = /9999-9999/;
var telefone = "9999-9999";
console.log(regExp.test(telefone));